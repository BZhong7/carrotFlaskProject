# Baby Carrot

# Getting Started

1. Install Flask:

        pip3 install flask

1. Install [sqlite3](https://www.sqlite.org/download.html)

1. Populate SQLite database

        sqlite3 interview-app.db < reset-interview-app.sql

1. Run the app:

        python3 project.py
