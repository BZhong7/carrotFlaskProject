DROP TABLE IF EXISTS expenses;
CREATE TABLE expenses (
  id INTEGER PRIMARY KEY NOT NULL,
  created_datetime TEXT NOT NULL,
  serviced_datetime TEXT NOT NULL,
  status TEXT NOT NULL,
  amount REAL NOT NULL
);

INSERT INTO expenses (id, created_datetime, serviced_datetime, status, amount)
VALUES (1, '2018-03-01T12:03:46.464116', '2018-03-01', 'RECEIVED', 10000),
       (2, '2018-03-01T12:44:24.689154', '2018-03-01', 'APPROVED', 20000),
       (3, '2018-03-01T12:44:25.532359', '2018-02-15', 'PAID', 5050),
       (4, '2018-03-01T12:44:26.072410', '2018-02-28', 'DENIED', 2490),
       (5, '2018-03-01T12:44:26.518451', '2018-01-01', 'RECEIVED', 1000000);
